# Todo App — SDD Brownfield Lab Starter

A minimal but fully working to-do web application. This is the starter codebase for **Module 4: Brownfield Lab** of the spec-driven development course. You'll add a new feature to it using SDD.

## Stack

- **Next.js 14** (App Router) for the framework
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **localStorage** for persistence — no database, no backend

The whole app is client-side. Refreshing the page preserves your data; clearing the browser storage wipes it.

## What it does today

- Add a task
- See all tasks in a single list
- Mark a task as done (and undo)
- Delete a task

That's it. There is no due date, no priority, no search, no sorting, no sync, no auth. **You'll add the due date in Module 4.**

## How to run it

You need **Node.js 18 or newer**. Check with:

```bash
node --version
```

Then, from this directory:

```bash
npm install
npm run dev
```

Open <http://localhost:3000> in your browser. You should see "My To-Dos" with an input box and an "Add" button. Add a few tasks, mark some done, refresh the page — everything should persist.

## Stop the app

`Ctrl+C` in the terminal running `npm run dev`.

## Project layout

```
.
├── app/
│   ├── components/
│   │   ├── TodoForm.tsx     # Input + Add button
│   │   ├── TodoList.tsx     # Renders the list (and empty state)
│   │   └── TodoItem.tsx     # Single row with checkbox and delete
│   ├── globals.css          # Tailwind directives only
│   ├── layout.tsx           # Root layout
│   └── page.tsx             # Main page — owns the todos state
├── lib/
│   └── storage.ts           # localStorage load/save helpers + Todo type
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── ...
```

About 200 lines of source code total. Small enough to read end-to-end before you start, which is exactly what Module 4 will ask you to do.

## Troubleshooting

**`npm install` fails with permission errors.** Don't use `sudo`. Either fix your npm install (e.g., switch to nvm) or use a different directory you own.

**Port 3000 is already in use.** `npm run dev -- -p 3001` will run on port 3001 instead.

**Tasks aren't persisting.** Open the browser devtools, go to Application → Local Storage, and check the entry for `http://localhost:3000`. If it's missing, your browser may be in private/incognito mode (some browsers don't persist localStorage there).

**Hot reload isn't working.** Stop the dev server (`Ctrl+C`) and restart it. If the issue persists, delete the `.next/` directory and restart.
