// Storage helpers for the todo app.

export type Todo = {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string; // ISO 8601 string
};

export function loadTodos(): Todo[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem("todos");
    if (!raw) return [];
    return JSON.parse(raw) as Todo[];
  } catch {
    return [];
  }
}

export function saveTodos(todos: Todo[]): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem("todos", JSON.stringify(todos));
}
